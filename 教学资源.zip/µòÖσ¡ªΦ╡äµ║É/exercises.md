# 🧪 MCP-Edge 教学任务清单

> 本任务清单适用于教学演示、学生实践与团队协作，涵盖部署、开发、运维与 AI 交互模块。

---

## 🧩 基础任务

### 1. 环境准备
- 安装 Docker 与 Portainer
- 克隆 Mcp-Edge 仓库并启动服务
- 验证 Traefik 网关是否自动申请 HTTPS

### 2. 数据库初始化
- 查看 `init/mongo-init.js` 与 `pg-init.sql`
- 使用 Adminer 或 phpMyAdmin 连接数据库
- 创建测试数据并执行基本查询

---

## 🛠️ 开发任务

### 3. Node.js API 服务
- 阅读 `server.js` 与 `routes/ai.js`
- 实现一个 `/api/healthz` 健康检查接口
- 将服务打包为 Docker 镜像并推送至 Docker Hub

### 4. 前端 UI 集成
- 拉取 `mcp-ui` 镜像并部署
- 配置 Traefik 路由至 `ui.localhost`
- 实现一个简单的 AI 聊天界面

---

## 🤖 AI 模块任务

### 5. AI 提示词实验
- 阅读 `教学资源/prompts.md`
- 使用 `/api/chat` 接口发送提示词
- 记录不同提示词的响应差异

### 6. 自定义 AI 服务
- 修改 `aiService.js` 接入本地模型或其他 API
- 添加日志记录与错误处理机制

---

## 📣 运维与协作任务

### 7. CI/CD 集成
- 阅读 `.github/workflows/ci-cd.yml`
- 添加构建版本号与 Slack 通知
- 推送代码并验证自动构建流程

### 8. Portainer Stack 部署
- 使用 Git 仓库部署 `docker-compose.yaml`
- 修改 `.env` 文件并观察服务变化
- 添加 Webhook 实现自动更新

---

## 🎓 教学展示任务

### 9. 幻灯片演示
- 使用 `slides.md` 生成教学幻灯片
- 演示部署流程与 AI 交互模块
- 分享遇到的问题与解决方案

### 10. 项目总结与优化
- 提交一份项目总结报告（Markdown）
- 提出改进建议与扩展方向
