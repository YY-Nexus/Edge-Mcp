* Teaching Resources
  * [Project Overview](/en/README.md)
  * [Slides](/en/slides.md)
  * [Exercises](/en/exercises.md)
  * [Lesson Plan](/en/lesson-plan.md)
  * [AI Prompts](/en/prompts.md)
