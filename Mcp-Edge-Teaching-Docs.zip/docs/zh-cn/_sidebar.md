* 教学资源
  * [项目介绍](/zh-cn/README.md)
  * [教学幻灯片](/zh-cn/slides.md)
  * [实践任务](/zh-cn/exercises.md)
  * [教学教案](/zh-cn/lesson-plan.md)
  * [AI提示词](/zh-cn/prompts.md)
